#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include "matrix.h"

double wtime(){
   struct timeval t;
   gettimeofday(&t, NULL);
   return t.tv_sec + t.tv_usec / 1000000.0;
}

int main(int argc, char **argv){
   double start_time, end_time;
    int nrows, ncols;

   if ((argc != 4)) {
      printf("Uso: %s <rows> <cols> <threads>\n", argv[0]);
      exit(EXIT_FAILURE);
   }

   nrows = atoi(argv[1]);
   ncols = atoi(argv[2]);
   int nthreads = atoi(argv[3]);

   start_time = wtime();

   matrix_t *tmp_block = matrix_create_block(nrows, ncols);

   matrix_t *tmp_pointers = matrix_create_pointers(nrows, ncols);

   // matrix_fill(tmp_block, 2);
   matrix_randfill(tmp_block);

   // matrix_print(tmp_block);

   // printf("\n\n");

   // matrix_t *res = matrix_sum_parallel(tmp_block, tmp_block, matrix_create_block, nthreads);

   // matrix_t *res = matrix_multiply_parallel(tmp_block, tmp_block, matrix_create_block, nthreads);
   // matrix_t *res = matrix_multiply(tmp_block, tmp_block, matrix_create_block);
      
   double res = matrix_determinant_LU(tmp_block, 8);
   printf("Det(A) = %f\n", res);
   printf("Det(A)* = %f\n", matrix_determinant(tmp_block, matrix_create_block));

   // matrix_print(res);
	
   // matrix_destroy_block(res);

   matrix_destroy_block(tmp_block);

   matrix_destroy_pointers(tmp_pointers);

   end_time = wtime();

   printf("%d %d %f\n", nrows, ncols, end_time - start_time);
   fflush(stdout);

   return EXIT_SUCCESS;
}
