#include <bits/stdc++.h>
using namespace std;

int main(){

    long maxsize = pow(64, 8);

    cout << maxsize << endl;

}